public class Main {
    public static void main(String[] args) {
        FitnessApp app = new FitnessApp();
        app.menu();
    }
}
